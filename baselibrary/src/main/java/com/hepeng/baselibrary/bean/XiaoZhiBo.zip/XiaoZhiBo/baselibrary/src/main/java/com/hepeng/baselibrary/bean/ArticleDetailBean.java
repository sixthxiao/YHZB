package com.hepeng.baselibrary.bean;

public class ArticleDetailBean {

    /**
     * createtime : 2019-09-05 16:21:29
     * fromsource : bb
     * titlepic : /article/2019-09-05/20190905162120_3mkdn50bq9.jpg
     * description : cc
     * viewcount : 10
     * ordernum : 0
     * id : 1
     * linkurl : null
     * title : aa
     * keyword :
     * content :
     */

    private String createtime;
    private String fromsource;
    private String titlepic;
    private String description;
    private int viewcount;
    private int ordernum;
    private int id;
    private String linkurl;
    private String title;
    private String keyword;
    private String content;

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getFromsource() {
        return fromsource;
    }

    public void setFromsource(String fromsource) {
        this.fromsource = fromsource;
    }

    public String getTitlepic() {
        return titlepic;
    }

    public void setTitlepic(String titlepic) {
        this.titlepic = titlepic;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getViewcount() {
        return viewcount;
    }

    public void setViewcount(int viewcount) {
        this.viewcount = viewcount;
    }

    public int getOrdernum() {
        return ordernum;
    }

    public void setOrdernum(int ordernum) {
        this.ordernum = ordernum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLinkurl() {
        return linkurl;
    }

    public void setLinkurl(String linkurl) {
        this.linkurl = linkurl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
