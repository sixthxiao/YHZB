package com.hepeng.baselibrary.bean;

public class WxSendNumBean {

    /**
     * totalnum : 0
     * surplusnum : 0
     */

    private int totalnum;
    private int surplusnum;

    public int getTotalnum() {
        return totalnum;
    }

    public void setTotalnum(int totalnum) {
        this.totalnum = totalnum;
    }

    public int getSurplusnum() {
        return surplusnum;
    }

    public void setSurplusnum(int surplusnum) {
        this.surplusnum = surplusnum;
    }
}
