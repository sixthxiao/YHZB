package com.hepeng.baselibrary.bean;

public class ReturnVisitBean {

    /**
     * adviceid : 32917
     */

    private String adviceid;

    public String getAdviceid() {
        return adviceid;
    }

    public void setAdviceid(String adviceid) {
        this.adviceid = adviceid;
    }
}
