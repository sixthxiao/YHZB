package com.yahu.live.home;


import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.yahu.live.R;
import com.yahu.live.base.MyPageChangeListener;
import com.yahu.live.utils.ImageUtils;
import com.yahu.live.utils.Util;
import com.zhouwei.mzbanner.MZBannerView;
import com.zhouwei.mzbanner.holder.MZHolderCreator;
import com.zhouwei.mzbanner.holder.MZViewHolder;

import java.util.ArrayList;
import java.util.List;

import static com.tencent.liteav.basic.log.TXCLog.init;


/**
 * Banner管理界面
 * 首页 推荐
 * Created by Dun on 2019/1/8.
 */

public class HomeRecommendFragment extends Fragment implements SwipeRefreshLayout.OnRefreshListener {
    private int mImageViewArray[] = {R.mipmap.banner, R.mipmap.banner, R.mipmap.banner, R.mipmap.banner, R.mipmap.banner};

    private SwipeRefreshLayout mSwipeRefreshLayout;
    private MZBannerView<String> mzBanner;
    private LinearLayout llIndicator;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home_tui, container, false);
        mSwipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipe_refresh_layout_list);
        mSwipeRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright,
                android.R.color.holo_green_light, android.R.color.holo_orange_light, android.R.color.holo_red_light);
        mSwipeRefreshLayout.setOnRefreshListener(this);

        mzBanner = (MZBannerView) view.findViewById(R.id.banner);
        llIndicator = view.findViewById(R.id.ll_indicator);
        fillActivity();
        return view;
    }

    /**
     * banner初始化
     */
    private  void  fillActivity(){
        if (isActivityDestroyed())
            return;

        ViewGroup.LayoutParams bannerParams = mzBanner.getLayoutParams();
        bannerParams.width = Util.getScreenWidth()-20;
        bannerParams.height = Util.getScreenWidth() * 7 / 16;
        mzBanner.setLayoutParams(bannerParams);
        mzBanner.setIndicatorVisible(false);

        llIndicator.removeAllViews();

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(Util.dip2px(6), Util.dip2px(6));
        params.rightMargin = Util.dip2px(10);
        for (int i = 0; i < mImageViewArray.length; i++) {
            View view = new View(getContext());
            view.setBackgroundResource(R.drawable.sel_home_banner_indicator);
            view.setSelected(i == 0);
            llIndicator.addView(view, params);
        }

        //模拟banner数据
        List<String> images = new ArrayList<>();
        for (int i = 0;i<mImageViewArray.length;i++){
            images.add("https://about.canva.com/wp-content/uploads/sites/3/2019/04/201904%E8%8A%82%E6%97%A5%E7%83%AD%E7%82%B9banner%E8%AE%BE%E8%AE%A1%E6%A8%A1%E6%9D%BF1.jpg");
        }
        // 设置数据
        mzBanner.setPages(images, new MZHolderCreator<BannerViewHolder>() {
            @Override
            public BannerViewHolder createViewHolder() {
                return new BannerViewHolder();
            }
        });

        mzBanner.addPageChangeListener(new MyPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);

                for (int i = 0; i < llIndicator.getChildCount(); i++) {
                    llIndicator.getChildAt(i).setSelected(i == position);
                }
            }
        });
    }

    public class BannerViewHolder implements MZViewHolder<String> {
        private ImageView mImageView;

        @Override
        public View createView(Context context) {
            // 返回页面布局
            View view = LayoutInflater.from(context).inflate(R.layout.layout_home_recommend_banner, null);
            mImageView = (ImageView) view.findViewById(R.id.banner_image);
            return view;
        }

        @Override
        public void onBind(Context context, int position, String data) {
            // 数据绑定
            ImageUtils.loadImage(context, data, mImageView);

//            mImageView.setTag(R.id.exo_position, position);
//            广告添加点击事件
//            mImageView.setOnClickListener(HomeRecommendFragment.this);
        }
    }


    private boolean isActivityDestroyed() {
        if (getActivity() == null)
            return true;
        return getActivity().isDestroyed();
    }
    @Override
    public void onResume() {
        mSwipeRefreshLayout.setRefreshing(false);
        super.onResume();
    }

    @Override
    public void onRefresh() {
        refreshListView();
    }

    /**
     * 刷新直播列表
     */
    private void refreshListView() {
        mSwipeRefreshLayout.post(new Runnable() {
            @Override
            public void run() {
                mSwipeRefreshLayout.setRefreshing(true);
            }
        });
    }
}
