package com.hepeng.baselibrary.bean;

public class AccountBean {

    /**
     * img : /doctor/2019-10-21/20191021211801_v20kcpp3ya.jpg
     * name : Time
     * id : 711
     * type : 128
     * account : oO5ct1JvCbiVcSehvnsgiZ8Xpdec
     * memberid : 20525
     */

    private String img;
    private String name;
    private int id;
    private int type;
    private String account;
    private int memberid;

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public int getMemberid() {
        return memberid;
    }

    public void setMemberid(int memberid) {
        this.memberid = memberid;
    }
}
