package com.hepeng.baselibrary.bean;

public class DiagnoseBean {

    /**
     * typecode : 1
     * py : qzhyz(zbxhz)
     * ordernum : 0
     * id : 3841
     * title : 气厥或郁厥(癔病性昏厥)
     * status : 0
     */

    private int typecode;
    private String py;
    private int ordernum;
    private int id;
    private String title;
    private int status;

    public int getTypecode() {
        return typecode;
    }

    public void setTypecode(int typecode) {
        this.typecode = typecode;
    }

    public String getPy() {
        return py;
    }

    public void setPy(String py) {
        this.py = py;
    }

    public int getOrdernum() {
        return ordernum;
    }

    public void setOrdernum(int ordernum) {
        this.ordernum = ordernum;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
