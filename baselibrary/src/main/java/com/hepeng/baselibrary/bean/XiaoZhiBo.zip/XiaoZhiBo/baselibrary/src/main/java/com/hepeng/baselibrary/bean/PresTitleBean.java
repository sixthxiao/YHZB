package com.hepeng.baselibrary.bean;

public class PresTitleBean {

    /**
     * count : 9
     */

    private int count;

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
