package com.hepeng.baselibrary.bean;

public class HospitalListBean {

    /**
     * keycode : 0
     * id : 2
     * hostype : 1
     * title : 国医在线
     */

    private String keycode;
    private String id;
    private String hostype;
    private String title;
    private String address;

    public String getKeycode() {
        return keycode;
    }

    public void setKeycode(String keycode) {
        this.keycode = keycode;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHostype() {
        return hostype;
    }

    public void setHostype(String hostype) {
        this.hostype = hostype;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
