package com.yahu.live.utils;



public class Constants {
    public static final int Register = 10;
}
