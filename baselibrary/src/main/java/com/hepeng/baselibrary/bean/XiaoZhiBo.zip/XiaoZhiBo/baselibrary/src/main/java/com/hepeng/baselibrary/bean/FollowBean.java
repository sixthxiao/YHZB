package com.hepeng.baselibrary.bean;

public class FollowBean {

    /**
     * adviceid : 8677
     * createtime : 2019/04/24
     * sex : 0
     * focus : 扫码
     * id : 3560
     * age : 10
     * realname : 娃娃
     * username : 福禄小金刚
     */

    private String adviceid;
    private String createtime;
    private int sex;
    private String focus;
    private int id;
    private int age;
    private String realname;
    private String username;

    public String getAdviceid() {
        return adviceid;
    }

    public void setAdviceid(String adviceid) {
        this.adviceid = adviceid;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public int getSex() {
        return sex;
    }

    public void setSex(int sex) {
        this.sex = sex;
    }

    public String getFocus() {
        return focus;
    }

    public void setFocus(String focus) {
        this.focus = focus;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getRealname() {
        return realname;
    }

    public void setRealname(String realname) {
        this.realname = realname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
