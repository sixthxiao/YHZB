package com.tencent.liteav.demo.beauty;

public class BeautyData {
    public int icon;
    public String text;

    public BeautyData(int icon, String text) {
        this.icon = icon;
        this.text = text;
    }
}
