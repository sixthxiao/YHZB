package com.hepeng.baselibrary.bean;

public class LoginBean {

    /**
     * logintype : 3
     * authtoken : Yg2PzP3Hd6hdu3Mf5M68x9JgEW3iD5aO
     */

    private int logintype;
    private String authtoken;

    public int getLogintype() {
        return logintype;
    }

    public void setLogintype(int logintype) {
        this.logintype = logintype;
    }

    public String getAuthtoken() {
        return authtoken;
    }

    public void setAuthtoken(String authtoken) {
        this.authtoken = authtoken;
    }
}
