package com.hepeng.baselibrary.bean;

public class FileUrlBean {

    /**
     * bucket : dev-1257318792
     * fileurl : /adv/2019-10-08/20191008162834_tluhc5ctgo.jpg
     */

    private String bucket;
    private String fileurl;

    public String getBucket() {
        return bucket;
    }

    public void setBucket(String bucket) {
        this.bucket = bucket;
    }

    public String getFileurl() {
        return fileurl;
    }

    public void setFileurl(String fileurl) {
        this.fileurl = fileurl;
    }
}
