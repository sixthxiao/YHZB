package com.hepeng.baselibrary.bean;

public class DoctorFlagBean {

    /**
     * strong : 0
     * phone : 0871-68505995
     * otropinion : 0
     * paypwd : 1
     */

    private String strong;
    private String phone;
    private String otropinion;
    private String paypwd;

    public String getStrong() {
        return strong;
    }

    public void setStrong(String strong) {
        this.strong = strong;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getOtropinion() {
        return otropinion;
    }

    public void setOtropinion(String otropinion) {
        this.otropinion = otropinion;
    }

    public String getPaypwd() {
        return paypwd;
    }

    public void setPaypwd(String paypwd) {
        this.paypwd = paypwd;
    }
}
