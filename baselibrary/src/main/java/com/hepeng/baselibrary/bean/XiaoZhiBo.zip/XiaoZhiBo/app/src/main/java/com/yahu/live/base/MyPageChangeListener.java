package com.yahu.live.base;


import androidx.viewpager.widget.ViewPager;

/**
 * Created by Dun on 2019/4/17.
 */

public class MyPageChangeListener implements ViewPager.OnPageChangeListener {
    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
